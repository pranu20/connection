# Degree-of-seperation
An App to find the degree of separation between any two people.

### Run with NPM
```
npm start
```

### Run with DOCKER
```
docker build -t app -f Dockerfile .
docker run --name=degreeOfSeperation -p 3000:30000 app
``` 
